#ifndef PCD8544_H
#define PCD8544_H

#include <WProgram.h>
#include <Print.h>

class PCD8544: public Print {
    public:
        // All the pins can be changed from the default values...
        PCD8544(unsigned char sclk = 7,
                unsigned char sdin = 6,
                unsigned char dc = 5,
                unsigned char reset = -1,
				unsigned char backlight = -1,
                unsigned char cs = -1);
              
        void init();
         
        void clear();
        
        void setBacklight(bool on);
		void setBacklight_PWM(int level);
		
        void setInverse(bool inverse);
        
        // Place the cursor at position (column, line)
        void setCursor(unsigned char column, unsigned char line);

        // Write a character at the current cursor position
        virtual void write(unsigned char chr);

        // Draw a bitmap at the current cursor position
        void drawBitmap(const unsigned char *data, unsigned char columns, unsigned char lines);

    private:
        unsigned char pin_sclk;
        unsigned char pin_sdin;
        unsigned char pin_dc;
        unsigned char pin_reset;
        unsigned char pin_cs;
        unsigned char pin_backlight;

        unsigned char curr_column;
        unsigned char curr_line;

        // Send a command or data to the display
        void command(unsigned char cmd);
        void data(unsigned char data);
        void send(unsigned char type, unsigned char data);
};

#endif
