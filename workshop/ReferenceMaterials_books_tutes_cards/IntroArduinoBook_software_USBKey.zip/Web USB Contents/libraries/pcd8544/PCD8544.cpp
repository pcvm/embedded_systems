#include "PCD8544.h"
#include <avr/pgmspace.h>

#define LCD_WIDTH 84
#define LCD_HEIGHT 48
#define LCD_NUMROWS (LCD_HEIGHT / 8)

#define PCD8544_CMD  LOW
#define PCD8544_DATA HIGH

#define PCD8544_POWERDOWN 0x04
#define PCD8544_ENTRYMODE 0x02
#define PCD8544_EXTENDEDINSTRUCTION 0x01

#define PCD8544_DISPLAYBLANK 0x0
#define PCD8544_DISPLAYNORMAL 0x4
#define PCD8544_DISPLAYALLON 0x1
#define PCD8544_DISPLAYINVERTED 0x5

// H = 0
#define PCD8544_FUNCTIONSET 0x20
#define PCD8544_DISPLAYCONTROL 0x08
#define PCD8544_SETYADDR 0x40
#define PCD8544_SETXADDR 0x80

// H = 1
#define PCD8544_SETTEMP 0x04
#define PCD8544_SETBIAS 0x10
#define PCD8544_SETVOP 0x80

#include "glcdfont.c"

PCD8544::PCD8544(unsigned char sclk, unsigned char sdin, 
                unsigned char dc, unsigned char reset,
                unsigned char backlight, unsigned char cs) :
                pin_sclk(sclk),
                pin_sdin(sdin),
                pin_dc(dc),
                pin_reset(reset),
				pin_backlight(backlight),
				pin_cs(cs)
{}

void PCD8544::init()
{
   pinMode(pin_sclk, OUTPUT);
   pinMode(pin_sdin, OUTPUT);
   pinMode(pin_dc, OUTPUT);
   if(pin_reset != -1){
     pinMode(pin_reset, OUTPUT);
   }
   if(pin_cs != -1){
     pinMode(pin_cs, OUTPUT);
   }
   if(pin_backlight != -1){
     pinMode(pin_backlight, OUTPUT);
   }
   if(pin_cs != -1){
     digitalWrite(pin_cs, HIGH);
   }
   if(pin_reset != -1){
     digitalWrite(pin_reset, LOW);
     delay(100);
     digitalWrite(pin_reset, HIGH);
   }
   // get into the EXTENDED mode  
   command(PCD8544_FUNCTIONSET | PCD8544_EXTENDEDINSTRUCTION);
   // LCD bias select (1:48)
   command(PCD8544_SETBIAS | 0x4);  // best for Sparkfun LCD
   command(PCD8544_SETBIAS | 0x3);  // best for Adafruit LCD
   // set VOP (3.06 + 66 * 0.06 = 7V)
   command(PCD8544_SETVOP | 0x42);
   // normal instruction set
   command(PCD8544_FUNCTIONSET);
   // turn all the pixels on
   command(PCD8544_DISPLAYCONTROL | PCD8544_DISPLAYALLON);
   
   clear();
   
   command(PCD8544_DISPLAYCONTROL);
   command(PCD8544_DISPLAYCONTROL | PCD8544_DISPLAYNORMAL);
   delay(100);
   
   setCursor(0,0);
}

inline void PCD8544::command(unsigned char cmd)
{
  send(PCD8544_CMD, cmd);
}

inline void PCD8544::data(unsigned char data)
{
  send(PCD8544_DATA, data);
}

// Is there a more efficient way to do this??
void PCD8544::clear()
{
  setCursor(0, 0);
  for(int i = 0; i < (LCD_WIDTH * LCD_NUMROWS); i++){
    data(0x00);
  }
  setCursor(0,0);
}

void PCD8544::setBacklight(bool on)
{
  if(pin_backlight != -1){
    digitalWrite(pin_backlight, on);
  }
}

void PCD8544::setBacklight_PWM(int level)
{
  if(pin_backlight != -1){
    analogWrite(pin_backlight, level);
  }
}

void PCD8544::setInverse(bool inverse)
{
  if(inverse){
    command(PCD8544_DISPLAYCONTROL | PCD8544_DISPLAYINVERTED);
  }
  else{
    command(PCD8544_DISPLAYCONTROL | PCD8544_DISPLAYNORMAL);
  }
}

void PCD8544::setCursor(unsigned char column, unsigned char line)
{
   curr_column = column % LCD_WIDTH;
   curr_line = line % LCD_NUMROWS;
   
   command(PCD8544_SETXADDR | curr_column);
   command(PCD8544_SETYADDR | curr_line);
}

void PCD8544::write(unsigned char chr)
{  
  unsigned char buffer[5] = {0x7e, 0x11, 0x11, 0x11, 0x7e};
  
  memcpy_P(buffer, &font[chr - ' '], sizeof(buffer));
  
  digitalWrite(13, HIGH);
  for(int i = 0; i < 5; i++){
    data(buffer[i]);
  }
  // one column between characters
  data(0x00);
  digitalWrite(13, LOW);
  
  curr_column = curr_column + 6;
  if(curr_column > LCD_WIDTH){
    curr_line = (curr_line + 1) % LCD_NUMROWS;
    curr_column %= LCD_WIDTH;
  }
}

void PCD8544::drawBitmap(const unsigned char *bmp_data, unsigned char columns, unsigned char lines)
{
  int startCol = curr_column;
  int startLine = curr_line;
  
  int org_columns = columns;
  // clip to right edge
  if((startCol + columns) > LCD_WIDTH){
    columns = LCD_WIDTH - startCol;
  }
  // clip to bottom
  if((startLine + lines) > LCD_NUMROWS){
    lines = LCD_NUMROWS - startLine;
  }
  for(int line = 0; line < lines; line++){
    setCursor(startCol, startLine + line);
    for(int col = 0; col < columns; col++){
      data(bmp_data[(line * org_columns) + col]);
    }
  }
  setCursor(startCol + columns, startLine);
}

void PCD8544::send(unsigned char type, unsigned char data)
{
   digitalWrite(pin_dc, type);
   if(pin_cs != -1){
     digitalWrite(pin_cs, LOW);
   }
   shiftOut(pin_sdin, pin_sclk, MSBFIRST, data);
   if(pin_cs != -1){
     digitalWrite(pin_cs, HIGH);
   }
}

