jQuery(function($){
	
	var app = window.app = {
		MAX_WIDTH: 84,
		MAX_HEIGHT: 6,

		selectWidth: $("<select>"),
		selectHeight: $("<select>"),
		
		drawDefault: true, // True when pencil is selected, false when eraser is selected
		drawCurrent: true, // Same as drawDefault when left-button is clicked, opposite when right-button is clicked
		drawing: false, // True when mouse is down
		
		grid: $("<table></table>"),
		preview: $("<table></table>"),
		
		output: $("<textarea></textarea>"),

		gridCells: [],
		previewCells: [],

		width: 8,
		height: 8,
		data: [],
		                                 
		init: function() {
			this.buildData();
			this.buildGrid().appendTo("body");
			var table = $('<table class="options" border="1"><tr><td></td><td></td><td></td></tr><tr><td colspan="3"></td></tr></table>');
			var tds = table.find("td");
			$(tds[0]).append("Preview:").append("<br>").append(this.buildPreview());
			$(tds[1]).append("Options:").append("<br>").append(this.buildOptions());
			$(tds[2]).append("Tools:").append("<br>").append(this.buildTools());
			$(tds[3]).append("Output:").append("<br>").append(this.buildImportError()).append(this.buildOutput());
			
			this.setSize(8,8);
			this.setDrawing();
			table.appendTo("body");
		},
		
		setSize: function(w,h) {
			// console.log("Selected image size of " + w + " by " + h);
			this.width = w;
			this.height = h;
			this.selectWidth.val(w);
			this.selectHeight.val(h);
			this.setTableSize(this.grid, w, h);
			this.setTableSize(this.preview, w, h);
			this.setDataSize(w, h);
			this.updateOutput();
		},
		setTableSize: function(table, w, h) {
			// Remove from DOM to reduce repainting triggered by style changes
			var dummy = document.createElement("div");
			table[0].parentNode.replaceChild(dummy, table[0]);
			
			var trs = table[0].firstChild.childNodes;
			for (var i=0; i < trs.length; i++) {
				var tr = trs[i];
				var hideRow = i >= h;
				tr.style.display = hideRow ? "none":"";
				var tds = tr.childNodes;
				for (var j=0; j < tds.length; j++) {
					var td = tds[j];
					var hideCell = j >= w;
					td.style.display = hideCell ? "none":"";
					if (hideCell || hideRow)
						td.className = "";
				}
			}
			
			// Readd to the DOM
			dummy.parentNode.replaceChild(table[0], dummy);
		},
		setDataSize: function(w, h) {
			for (var x=0; x < this.MAX_WIDTH; x++) {
				for (var y=0; y < this.MAX_HEIGHT; y++) {
					if (x >= w || y*8 >= h)
						this.data[x][y] = 0;
				}
			}
		},

		buildData: function() {
			for (var x=0; x < this.MAX_WIDTH; x++) {
				this.data[x] = [];
				for (var y=0; y < this.MAX_HEIGHT; y++) {
					this.data[x][y] = 0;
				}
			}
		},

        buildOptions: function() {
			for (var i=0; i < this.MAX_WIDTH; i++)
				$('<option>').text(i+1).val(i+1).appendTo(this.selectWidth);

			for (var i=0; i < this.MAX_HEIGHT; i++)
				$('<option>').text((i+1)*8).val((i+1)*8).appendTo(this.selectHeight);

			var divOptions = $("<div></div>")
				.append("Image width: ")
				.append(this.selectWidth)
				.append("<br>")
				.append("Image height: ")
				.append(this.selectHeight);
				
			var self = this;
			var updateSize = function() {
				self.setSize(parseInt(self.selectWidth.val()), parseInt(self.selectHeight.val()));
			};
			this.selectWidth.change(updateSize);
			this.selectHeight.change(updateSize);

			return divOptions;
		},
		buildTools: function() {
			var drawLink = $('<a href="#" class="draw" title="Draw"><img src="pencil.png"></a>');
			var eraseLink = $('<a href="#" class="erase" title="Erase"><img src="eraser.png"></a>');
			
			var self = this;
			var divTools = $("<div></div>")
				.append(drawLink)
				.append(eraseLink)
				.append('<div class="drawhint">Left-click to draw, right-click to erase</div>')
				.append('<div class="erasehint">Left-click to erase, right-click to draw</div>');
			
			drawLink.click(function() {
				self.setDrawing();
				return false;
			});
			eraseLink.click(function() {
				self.setErasing();
				return false;
			});
			
			return divTools;
		},
	
		getCellFromEvent: function(event) {
			var td = event.srcElement || event.originalEvent.originalTarget;
			if (td && td.nodeName == "TD")
				return td;
			else
				return null;
		},
		
		buildGrid: function() {
			var self = this;
			this.grid.addClass("grid").mousedown(function(event){
				if (event.button == 2) {
					// Invert drawing for right-clicks, prevent context menu
					self.drawCurrent = !self.drawDefault;
					event.preventDefault();
				}   
				else {
					self.drawCurrent = self.drawDefault;
				}

				var td = self.getCellFromEvent(event);
				if (td) {
					var x = td.x;
					var y = td.y;
					self.toggleCell(x, y, self.drawCurrent);
					self.drawing = true;
				}
			}).mousemove(function(event) {
				if (self.drawing) {
					var td = self.getCellFromEvent(event);
					if (td) {
						var x = td.x;
						var y = td.y;
						self.toggleCell(x, y, self.drawCurrent);
					}
				}
			}).bind("dragstart", false).bind("drag", false).bind("dragend", false).bind("contextmenu", false);

			$("body").mouseup(function(event) {
				delete self.drawing;
			});

			this.buildTable(this.grid, this.gridCells);
			return this.grid;
		},

		buildPreview: function() {
			this.preview.addClass("preview");
			this.buildTable(this.preview, this.previewCells);
			return this.preview;
		},
		
		buildTable: function(table, cells) {
			table.empty();
			cells.length = 0;
			var d = document;
			for (var y = 0; y < this.MAX_HEIGHT * 8; y++) {
				var tr = d.createElement("tr");
				for (var x = 0; x < this.MAX_WIDTH; x++) {
					var td = d.createElement("td");
						td.x = x;
						td.y = y;
					tr.appendChild(td);

					if (!cells[x])
					    cells[x] = [];
					cells[x][y] = $(td);
				}
				table.append(tr);
			}
		},

		toggleCell: function(x, y, on) {
			//console.log("Toggle " + x + "," + y + " force="+on);
			if (!(x >= 0 && y >= 0))
				return;
			
			var dataX = x;
			var dataY = Math.floor(y/8);
			var datum = this.data[dataX][dataY];

			var bit = 1 << (y%8);
			var wasOn = (datum & bit) > 0;
			if (wasOn != on) {
				if (on)
					this.setData(dataX, dataY, datum | bit);
				else
					this.setData(dataX, dataY, datum & (0xff ^ bit));
				this.updateOutput();
			}
		},
		setData: function(dataX, dataY, datum) {
			if (this.data[dataX][dataY] == datum)
				return;
			
			this.data[dataX][dataY] = datum;
			for (var i = 0; i < 8; i++) {
				var x = dataX;
				var y = dataY*8 + i;

				var on = (datum & (1 << i)) > 0;
				this.gridCells[x][y].toggleClass("on", on);
				this.previewCells[x][y].toggleClass("on", on);
			}
		},

		buildOutput: function() {
			var self = this;
			var delayedImport = function(event) {
				// Delay to give the pasted content time to change the textarea value
				setTimeout(function() {
					self.importData(self.output.val());
				},1);
			};
			
			this.output.change(function(event) {
				self.importData(this.value);
			})
			.keypress(function(event) {
				if (event.metaKey || event.ctrlKey)
					return;
				// Respond to keypresses that insert text or remove text (delete==8, backspace==46)
				if (event.charCode || event.keyCode == 8 || event.keyCode == 46) {
					// Delay to give the keypress time to change the textarea value
					setTimeout(function() {
						self.importData(self.output.val());
					},1);
				}
			})
			.bind("paste", delayedImport)
			.bind("cut", delayedImport);
			
			this.output.attr("wrap","off").addClass("output");
			return this.output;
		},
		updateOutput: function() {
			if (this.deferUpdatingOutput)
				return;
			if (this._updateOutputTimer)
				return;
			var self = this;
			this._updateOutputTimer = setTimeout(function(){
				self._updateOutput();
			},200);
		},
		_updateOutput: function() {
			delete this._updateOutputTimer;
			var rows = [];
			for (var y=0; y < this.height/8; y++) {
				var bytes = [];
				for (var x=0; x < this.width; x++) {
					var str = this.data[x][y].toString(16).toUpperCase();
					if (str.length == 1)
						str = "0" + str;
					bytes.push("0x" + str);
				}
				rows.push(bytes.join(", "));
			}

			var rowModifier = (rows.length == 1) ? "" : (rows.length + " * ");
			this.lastOutputValue = "const byte my_image[" + rowModifier + this.width + "] = {\n\t" 
				+ rows.join(",\n\t") 
				+ "\n};";
			this.output.val(this.lastOutputValue);
			this.setImportError(null);
		},
		
		buildImportError: function() {
			this.importError = $("<div></div>").addClass("error").hide();
			return this.importError;
		},
		setImportError: function(error) {
			if (error) {
				this.importError.text(error).show();
			}
			else {
				this.importError.empty().hide();
			}
		},
		
		importData: function(str) {
			if (str == this.lastOutputValue)
				return;
			this.lastOutputValue = str;
			
			var normalized = str.replace(/[\s]/g, "");
			var match = normalized.match(/\[(?:([0-9]+)\*)?([0-9]+)\]=\{([^}]*)\}/);
			if (match) {
				var rows = parseInt(match[1] || "1");
				var cols = parseInt(match[2]);
				var bytes = [];
				try {
					bytes = eval("["+match[3]+"]");
				} catch(e) {
					this.setImportError("Invalid data: " + e);
					return;
				}
				
				if (rows < 1 || rows > this.MAX_HEIGHT) {
					this.setImportError("Cannot have more than 6 byte-rows");
					return;
				}
				if (cols < 1 || cols > this.MAX_WIDTH) {
					this.setImportError("Cannot have more than " + this.MAX_WIDTH + " columns");
					return;
				}
				if (!bytes || !(bytes.length >= 0)) {
					this.setImportError("Invalid data");
					return;
				}
				if (bytes.length < rows*cols) {
					this.setImportError("Data length ("+bytes.length+") doesn't match array declaration ("+rows+"*"+cols+"="+(rows*cols)+"). 0-bytes will be used for missing elements");
				}
				else if (bytes.length > rows*cols) {
					this.setImportError("Data length ("+bytes.length+") doesn't match array declaration ("+rows+"*"+cols+"="+(rows*cols)+"). Extra bytes will be ignored");
				}
				else {
					this.setImportError(null);
				}
				
				this.deferUpdatingOutput = true;
				for (var dataX = 0; dataX < cols; dataX++) {
					for (var dataY = 0; dataY < rows; dataY++) {
						this.setData(dataX, dataY, bytes[dataX + dataY*cols] || 0);
					}
				}
				this.setSize(cols, rows*8);
				this.deferUpdatingOutput = false;
				
				console.log("Importing: " + rows + " rows X " + cols + " cols, ", bytes);
			}
			else {
				this.setImportError("Invalid format");
			}
			
		},
		
		setDrawing: function() {
	   		this.drawDefault = this.drawCurrent = true;
			delete this.drawing;
			$("body").removeClass("erasing").addClass("drawing");
		},
		setErasing: function() {
	   		this.drawDefault = this.drawCurrent = false;
			delete this.drawing;
			$("body").addClass("erasing").removeClass("drawing");
		}   
	};

	app.init();
})